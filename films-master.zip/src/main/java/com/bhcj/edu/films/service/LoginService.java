package com.bhcj.edu.films.service;

import com.bhcj.edu.films.entity.User;

public interface LoginService{
    User getUserByName(String userName);
}
