package com.bhcj.edu.films;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LxcApplicationTests {

    @Test
    void contextLoads() {
    }

}
